<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Tranksaksi;

class Pasien extends Model
{
    use HasFactory;
    protected $fillable = [
        'no_rm',
        'nama',
        'domisili',
        'tanggal_lahir',
        'no_hp',
        'jenis_kelamin',
        'nik',
        'deleted_at',
    ];

    public function transaksi()
    {
        return $this->hasMany(Tranksaksi::class);
    }
}
